using Godot;
using System;

public partial class ButtonSair : Button
{
	private void Sair()
	{
		GetTree().ChangeSceneToFile("res://Main/cenasMain/menu_principal.tscn");
	}
}
