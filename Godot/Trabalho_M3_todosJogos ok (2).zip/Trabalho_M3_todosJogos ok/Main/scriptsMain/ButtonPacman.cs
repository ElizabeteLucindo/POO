using Godot;
using System;

public partial class ButtonPacman : Button
{
	
	private void pacman()
	{
		GetTree().ChangeSceneToFile("res://Pacman/CenasPacman/menu.tscn");
	}
}


