using Godot;
using System;

public partial class ButtonFireboy : Button
{
	private void JogarFireboy(){
		GetTree().ChangeSceneToFile("res://Fireboy/cenasFireboy/menu_fireboy.tscn");
	}
}



