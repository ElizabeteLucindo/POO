using Godot;
using System;

public partial class ButtonSairMain : Button
{
	
	private void sairMain()
	{
		GetTree().Quit();
	}
}


