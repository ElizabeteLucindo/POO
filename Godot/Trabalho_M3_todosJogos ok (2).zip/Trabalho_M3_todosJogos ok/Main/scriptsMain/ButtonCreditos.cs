using Godot;
using System;

public partial class ButtonCreditos : Button
{
	private void _on_pressed()
	{
		GetTree().ChangeSceneToFile("res://Main/cenasMain/creditos.tscn");
	}
}
