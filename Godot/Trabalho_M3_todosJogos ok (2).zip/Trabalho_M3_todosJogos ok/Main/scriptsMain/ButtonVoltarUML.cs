using Godot;
using System;

public partial class ButtonVoltarUML : Button
{
	private void voltarUML()
	{
		GetTree().ChangeSceneToFile("res://Main/cenasMain/menu_principal.tscn");
	}
}
