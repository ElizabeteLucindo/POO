using Godot;
using System;

public partial class ButtonMC : Button
{
	private void JogarMC(){
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/menu_melissa_case.tscn");
	}
}
