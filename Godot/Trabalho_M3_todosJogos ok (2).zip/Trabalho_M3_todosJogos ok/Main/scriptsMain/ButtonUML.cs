using Godot;
using System;

public partial class ButtonUML : Button
{
	private void UML_pressed()
	{
		GetTree().ChangeSceneToFile("res://Main/cenasMain/uml.tscn");
	}

}
