using Godot;
using System;

public partial class ButtonVoltarMenuMain : Button
{
	private void _on_pressed()
	{
		GetTree().ChangeSceneToFile("res://Main/cenasMain/menu_principal.tscn");
	}
}
