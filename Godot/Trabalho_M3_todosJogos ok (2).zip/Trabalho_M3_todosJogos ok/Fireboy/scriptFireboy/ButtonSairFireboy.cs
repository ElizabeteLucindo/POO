using Godot;
using System;

public partial class ButtonSairFireboy : Button
{
	
	private void sair_fireboy()
	{
		GetTree().ChangeSceneToFile("res://Main/cenasMain/menu_principal.tscn");
	}
}
