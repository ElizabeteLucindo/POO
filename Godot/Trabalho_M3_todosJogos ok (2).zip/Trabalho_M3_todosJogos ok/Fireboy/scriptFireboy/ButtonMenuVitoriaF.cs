using Godot;
using System;

public partial class ButtonMenuVitoriaF : Button
{
	

	private void menu_vitoria_f()
	{
		GetTree().ChangeSceneToFile("res:///Fireboy/cenasFireboy/menu_fireboy.tscn");
	}
}

