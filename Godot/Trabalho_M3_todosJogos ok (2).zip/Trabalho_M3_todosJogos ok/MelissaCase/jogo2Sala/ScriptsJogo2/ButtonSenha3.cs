using Godot;
using System;

public partial class ButtonSenha3 : Button
{
	private void senha3_correta()
	{
		Global.liberaCasa1 = true;
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/CenaSala.tscn");
	}
}
