using Godot;
using System;

public partial class ButtonVoltar3Papel : Button
{
	private void _on_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/CenaSala.tscn");
	}

}
