using Godot;
using System;

public partial class ButtonVoltar1Sala : Button
{
	private void _on_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/CenaSala.tscn");
	}
}
