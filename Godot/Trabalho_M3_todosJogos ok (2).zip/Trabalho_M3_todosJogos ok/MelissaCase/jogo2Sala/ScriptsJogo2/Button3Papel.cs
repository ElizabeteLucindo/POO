using Godot;
using System;

public partial class Button3Papel : Button
{
	private void dica3_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/dica_3_papel.tscn");
	}

}
