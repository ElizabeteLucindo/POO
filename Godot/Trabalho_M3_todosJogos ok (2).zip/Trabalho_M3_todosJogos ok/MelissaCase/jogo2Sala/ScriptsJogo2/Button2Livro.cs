using Godot;
using System;

public partial class Button2Livro : Button
{
	private void dica2_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/dica_2_livro.tscn");
	}
}

