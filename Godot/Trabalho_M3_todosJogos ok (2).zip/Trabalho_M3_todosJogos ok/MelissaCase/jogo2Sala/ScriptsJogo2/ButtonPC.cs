using Godot;
using System;

public partial class ButtonPC : Button
{
	private jogador_fbi jogador;
	
	public override void _Ready() {
		 jogador = GetNodeOrNull<jogador_fbi>("../JogadorFBI");
	}
	private void botao_pc()
	{
		GD.Print(Global.ItensColetados);
		if (Global.ItensColetados >= 60){
			GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/cena_pc.tscn");
		}
	}
}
