using Godot;
using System;

public partial class ButtonSenha1 : Button
{
	private void senha1_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/CenaSala.tscn");
	}
}
