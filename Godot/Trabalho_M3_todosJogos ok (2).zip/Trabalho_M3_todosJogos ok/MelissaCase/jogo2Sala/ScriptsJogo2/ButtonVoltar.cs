using Godot;
using System;

public partial class ButtonVoltar : Button
{
	private void voltar()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/CenaSala.tscn");
	}
}
