using Godot;
using System;

public partial class ButtonTelefone : Button
{
	private void telefone_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/numero_telefone.tscn");
	}
}
