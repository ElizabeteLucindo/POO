using Godot;
using System;

public partial class ButtonSenha2 : Button
{
	private void senha2_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/CenaSala.tscn");
	}
}
