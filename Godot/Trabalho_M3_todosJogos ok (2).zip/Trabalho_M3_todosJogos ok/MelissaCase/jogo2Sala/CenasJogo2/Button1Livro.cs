using Godot;
using System;

public partial class Button1Livro : Button
{
	
	private void dica1_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/dica_1_livro.tscn");
	}
}
