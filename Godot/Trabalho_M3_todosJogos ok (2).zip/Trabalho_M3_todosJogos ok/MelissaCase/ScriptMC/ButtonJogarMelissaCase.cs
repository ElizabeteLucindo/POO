using Godot;
using System;

public partial class ButtonJogarMelissaCase : Button
{
	private void botao_jogar_melissaCase()
	{
		Global.ItensColetados = 0;
		Global.MoedasColetados = 0;
		Global.galaoColetado = false;
		Global.liberaCasa1 = false;
		Global.senhaCorreta = false;
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/cena_inicial.tscn");
	}
}



