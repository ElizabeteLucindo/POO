using Godot;
using System;

public partial class jogador_fbi : CharacterBody2D
{
	private Vector2 direcao;
	private AnimatedSprite2D anima; 
	public int pontuacao { get; private set; } = 0;
	
	//export serve para exibir na interface do Godot
	[Export] private float velocidade = 180f;
	
	public override void _Ready() {
		anima = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
	}

	public void Controle() {
		direcao = Vector2.Zero;
		//anima.Play("idle");
		if ( Input.IsActionPressed("esquerda") ) {
			direcao.X = -1;
			anima.Play("correr");
			anima.FlipH = true; 
			
		}
		else if ( Input.IsActionPressed("direita") ) {
			direcao.X = 1;
			anima.Play("correr");
			anima.FlipH = false; 
			
		}else {
			anima.Play("idle");
		}
		if ( Input.IsActionPressed("cima") ) {
			direcao.Y = -1;
			anima.Play("idle");
			
		}
		if ( Input.IsActionPressed("baixo") ) {
			direcao.Y = 1;
			anima.Play("idle");
			
		}
		
		
		
		
	}
	public override void _Process(double delta)
	{
		Controle(); //verifica as ações do controle
		Velocity = direcao * velocidade;
		MoveAndSlide();
	}

	
	public void IncrementarPontuacao(int valor){
		pontuacao += valor;
		Global.ItensColetados += valor;
		GD.Print("Pontuação: " + pontuacao);
	}
	
	 // Método para obter a pontuação atual
	public int GetPontuacao()
	{
		return pontuacao;
	}
}
