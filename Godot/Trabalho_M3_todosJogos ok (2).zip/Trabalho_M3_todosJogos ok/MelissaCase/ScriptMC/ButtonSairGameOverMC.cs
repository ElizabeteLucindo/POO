using Godot;
using System;

public partial class ButtonSairGameOverMC : Button
{
	
	private void _on_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/menu_melissa_case.tscn");
	}

}
