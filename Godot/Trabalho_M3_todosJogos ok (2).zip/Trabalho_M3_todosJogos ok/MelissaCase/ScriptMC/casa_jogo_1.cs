using Godot;
using System;

public partial class casa_jogo_1 : Area2D
{
	private double tempo;
	private bool entrou = false;
	private AnimatedSprite2D anima; 
	public override void _Ready() {
		anima = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
	}

	public override void _Process(double delta)
	{
		if (entrou){
			tempo = tempo + delta;
			anima.Play("abrir1");
			if (Global.liberaCasa1){
				if (tempo >= 0.75) {
					GetTree().ChangeSceneToFile("res://MelissaCase/jogo4Plataforma/CenasJogo4/plataforma_casa_1.tscn");
				}
			}
		}else {
			anima.Play("idle1");
		}
	}
	
	
	private void Entrou(Node2D body)
	{
		if (body is jogador_fbi && Global.liberaCasa1){
			tempo=0;
		entrou = true;
		}
	}
}
