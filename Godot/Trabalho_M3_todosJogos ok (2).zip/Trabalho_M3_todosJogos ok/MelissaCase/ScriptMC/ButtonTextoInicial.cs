using Godot;
using System;

public partial class ButtonTextoInicial : Button
{
	private void botao_texto_inicial()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/mapa_3.tscn");
	}
}
