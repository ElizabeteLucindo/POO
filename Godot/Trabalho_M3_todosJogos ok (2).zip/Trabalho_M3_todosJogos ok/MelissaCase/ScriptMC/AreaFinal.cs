using Godot;
using System;

public partial class AreaFinal : Area2D
{
	private void _on_body_entered(Node2D body)
	{
		if (Global.senhaCorreta){
			GetTree().ChangeSceneToFile("res://MelissaCase/jogo1Coletar/CenasJogo1/dialogo_jogo_1.tscn");
		}
	}
}

