using Godot;
using System;

public partial class BombaGasolina : Area2D
{
	
	private void entrou_bombaGasolina(Node2D body)
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo3Labirinto/CenasJogo3/labirinto.tscn");
	}
}
