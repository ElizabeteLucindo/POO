using Godot;
using System;

public partial class CarroPolicia : Area2D
{
	
	private void entrou_carroPolicia(Node2D body)
	{
		if (Global.galaoColetado){
			GetTree().ChangeSceneToFile("res://MelissaCase/jogo1Coletar/CenasJogo1/cena_sargento.tscn");
		}
	}
}
