using Godot;
using System;

public partial class Sala2 : Area2D
{
	private void Entrou(Node2D body)
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/jogo2Sala/CenasJogo2/CenaSala.tscn");
	}
}
