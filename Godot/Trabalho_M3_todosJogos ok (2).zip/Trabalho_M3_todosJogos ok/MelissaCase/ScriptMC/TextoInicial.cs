using Godot;
using System;

public partial class TextoInicial : RichTextLabel
{
	[Export]
	public string TextoCompleto =  "Você foi recrutado para um caso crucial do FBI: encontrar a Agente Melissa, desaparecida durante uma investigação em Las Vegas. Sua missão é usar pistas e suas habilidades como agente secreto para encontrar a Agente Melissa com vida o mais rápido possível.";

	private string textoAtual = "";
	private int indiceAtual = 0;
	private Timer timer;

	public override void _Ready()
	{
		// Configuração inicial
		Clear(); // Limpa o RichTextLabel
		timer = GetNode<Timer>("TimerTextoInicial");
		StartDigitar(); // Inicia o efeito de digitação
	}

	private void StartDigitar()
	{
		textoAtual = "";
		indiceAtual = 0;
		Text = ""; // Usando a propriedade Text para definir o texto inicialmente vazio

		timer.Start();
	}

	private void  _on_timer_texto_inicial_timeout()
	{
		if (indiceAtual < TextoCompleto.Length) 
		{
			textoAtual += TextoCompleto[indiceAtual];
			Text = textoAtual; // Atualiza o texto diretamente usando a propriedade Text
			indiceAtual++;
		}
		else
		{
			timer.Stop();
		}
	}
}
