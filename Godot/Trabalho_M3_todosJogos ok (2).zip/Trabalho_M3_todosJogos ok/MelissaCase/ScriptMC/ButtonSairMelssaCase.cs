using Godot;
using System;

public partial class ButtonSairMelssaCase : Button
{
	private void botao_sair_melissaCase()
	{
		GetTree().ChangeSceneToFile("res://Main/cenasMain/menu_principal.tscn");
	}
}
