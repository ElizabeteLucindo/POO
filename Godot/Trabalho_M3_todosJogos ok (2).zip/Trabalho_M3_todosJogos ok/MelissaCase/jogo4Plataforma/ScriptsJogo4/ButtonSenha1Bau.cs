using Godot;
using System;

public partial class ButtonSenha1Bau : Button
{
	private void Senha1Bau()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/mapa_3.tscn");
	}
}
