using Godot;
using System;

public partial class bau : Area2D
{
	private void entrou_bau(Node2D body)
	{
		if (Global.MoedasColetados >= 190){
			GetTree().ChangeSceneToFile("res://MelissaCase/jogo4Plataforma/CenasJogo4/senha_bau.tscn");
		}
	}
}
