using Godot;
using System;

public partial class moedas : Area2D
{
	public int ValorPonto = 10;
	public void Coletada(Node2D body) {
		jogador_fbi_2 j;
		if (body is jogador_fbi_2) {
			j = (jogador_fbi_2)body;
			j.IncrementarPontuacao(ValorPonto);
		QueueFree();
		}	
	}
}
