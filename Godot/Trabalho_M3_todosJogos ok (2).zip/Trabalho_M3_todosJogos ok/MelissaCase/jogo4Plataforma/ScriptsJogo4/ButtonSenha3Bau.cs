using Godot;
using System;

public partial class ButtonSenha3Bau : Button
{
	private void senha3Bau()
	{
		Global.senhaCorreta = true;
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/mapa_3.tscn");
	}
}
