using Godot;
using System;

public partial class ButtonSenha2Bau : Button
{
	private void senha2Bau()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/mapa_3.tscn");
	}

}
