using Godot;
using System;

public partial class ButtonSairJogo1 : Button
{
	private void _on_pressed()
	{
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/menu_melissa_case.tscn");
	}
}
