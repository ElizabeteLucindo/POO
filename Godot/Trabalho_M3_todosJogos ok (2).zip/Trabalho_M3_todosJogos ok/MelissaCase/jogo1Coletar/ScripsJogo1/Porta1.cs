using Godot;
using System;

public partial class Porta1 : Area2D
{
	private jogador_fbi jogador;
	private double tempo;
	private bool entrou = false;
	private AnimatedSprite2D anima; 
	
	public override void _Ready() {
		anima = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
	}

	public override void _Process(double delta)
	{
		if (entrou){
			tempo = tempo + delta;
			anima.Play("abrir");
			if (tempo >= 0.75) {
				
				GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/mapa_3.tscn");
			}	
		}
	}
	
	
	private void entrou_porta_1(Node2D body)
	{
		if (body is jogador_fbi){
			tempo=0;
		entrou = true;
		}
	}
}
