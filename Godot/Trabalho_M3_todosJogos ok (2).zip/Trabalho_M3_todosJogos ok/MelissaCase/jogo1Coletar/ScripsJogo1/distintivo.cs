using Godot;
using System;

public partial class distintivo : Area2D
{
	public int ValorPonto = 10;
	public void Coletada(Node2D body) {
		jogador_fbi j;
		if (body is jogador_fbi) {
			j = (jogador_fbi)body;
			j.IncrementarPontuacao(ValorPonto);
		QueueFree();
		}
	}
}
