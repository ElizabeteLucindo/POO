using Godot;
using System;

public partial class Global : Node
{
	public static int ItensColetados { get; set; } = 0;
	public static int MoedasColetados { get; set; } = 0;
	public static bool galaoColetado { get; set; } = false;
	public static bool liberaCasa1 { get; set; } = false;
	public static bool senhaCorreta { get; set; } = false;
	
}
