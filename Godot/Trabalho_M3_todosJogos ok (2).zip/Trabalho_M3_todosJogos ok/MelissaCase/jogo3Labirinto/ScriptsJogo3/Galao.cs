using Godot;
using System;

public partial class Galao : Area2D
{
	
	private void entrou_galao(Node2D body)
	{
		Global.galaoColetado = true;
		GetTree().ChangeSceneToFile("res://MelissaCase/CenasMC/mapa_3.tscn");
	}
}
